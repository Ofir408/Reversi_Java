
import java.util.Scanner;
import java.util.Vector;


public class GameRunner {
	/*
	 * GameRunner.cpp
	 *
	 *  Created on: Nov 9, 2017
	 *      Author: Ofir Ben-Shoham.
	 */

	private Board board;
	private GameLogic gameLogic;
	private char currentPlayer;

	
	
	GameRunner(Board b, char player) {
		this.board = b;
		this.gameLogic = new GameLogic(b);
		this.currentPlayer = player;
	}

	Cell getUserInput() {

		Cell inputCell = askInput();

		if (!checkValidInput(inputCell)) {
			do {
				if (!gameLogic.canAssign(this.currentPlayer, inputCell)) {
					System.out.println("\n You didn't choose from your options.");
				}
				System.out.println( "Your choice doesn't legal");
				inputCell = askInput();
			} while (!checkValidInput(inputCell));
		}
		return inputCell;
	}

	boolean checkValidInput(Cell inputCell) {
		return inputCell.isEmptyCell() && inputCell.isValid()
				&& gameLogic.canAssign(this.currentPlayer, inputCell);
	}

	// come to this function with the knowledge that we can continue in the game.
	// It means that at least for one player has a possible move to do.
	//returns the next player that should play.
	char playNextMove(int x, int y) {

		boolean turnMade;
		if (!this.gameLogic.hasPossibleMoves(this.currentPlayer)) {
			String userPassesChecking;
			System.out.println("\n No Possible Moves. Play passes back to the other player.\n "
				+	"Press any key to continue and then press on Enter.");
			 Scanner in = new Scanner(System.in);
			 userPassesChecking = in.nextLine();
			 in.close();
			if (userPassesChecking.length() != 0) {
				// switch the turn to the other player.
				this.switchCurrentPlayer();

				Cell userInput = new Cell(x, y, this.currentPlayer); // gets input from the user
				turnMade = gameLogic.inputAssignManager(currentPlayer, userInput);
				this.board = gameLogic.getBoard();

				// after he made his turn, switch the current player.
				if (turnMade) {
					this.switchCurrentPlayer();
				}
			}
		} else {
			Cell userInput = new Cell(x, y, this.currentPlayer); // gets input from the user
			turnMade = gameLogic.inputAssignManager(this.currentPlayer, userInput);
			this.board = gameLogic.getBoard();
			// after he made his turn, switch the current player.
			if (turnMade) {
				this.switchCurrentPlayer();
			}
		}
		return this.currentPlayer;
	}

	boolean canToContinue() {
			// The game is ended when all the board is full or no more moves
			// is possible for the players.
			char before = this.currentPlayer; // the first.
			switchCurrentPlayer();
			char after = this.currentPlayer;  // the second.
			boolean b1 = board.possibleCellsToAssign(before).isEmpty();
			boolean b2 = board.possibleCellsToAssign(after).isEmpty();

			if (this.board.isBoardFull() || (b1 && b2)) {
				this.currentPlayer = before;
				return false; // need to stop.
			}
			this.currentPlayer = before;
			return true; // otherwise, can to continue in the game.
	}

	Cell askInput() {
		String lineInput; //, secondInput;
		
		Scanner scan = new Scanner(System.in);
		lineInput = scan.next(); // get the line from the user . 

		int temp = lineInput.indexOf(",");
		if (temp < 0) 
			return new Cell(-1, -1, ' ');
		String r = lineInput.substring(0, temp);
		String s = lineInput.substring(temp + 1);
		try {
			int inputRow = Integer.parseInt(r);
			int inputCol = Integer.parseInt(s);
			Cell inputCell = new Cell(inputRow, inputCol, ' ');
			return inputCell;
		} catch (Exception e) {
			return new Cell(-1, -1, ' '); // can't assign this.
		}
		
	}

	void switchCurrentPlayer() {
		if (currentPlayer == 'X') {
			this.currentPlayer = 'O';
		} else {
			currentPlayer = 'X'; // because it was 'O'.
		}
	}
	
}