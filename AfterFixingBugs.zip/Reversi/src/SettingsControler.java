
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class SettingsControler implements Initializable {

	@FXML
	private TextField boardSize;
	@FXML
	private RadioButton playerOne;
	@FXML
	private RadioButton playerTwo;
	private ToggleGroup players; // indicates who is the first player to start
									// in the game.
	@FXML
	private TextField firstPlayerColor;
	@FXML
	private TextField secondPlayerColor;
	@FXML
	private Node saveSettingsButton;
	@FXML
	private Text start;
	@FXML
	private Text one;
	@FXML
	private Text two;
	@FXML
	private Text size;
	
	/**
	 * This function is called when the save settings button is pressed. We want
	 * to save the new settings to gameData file.
	 * @throws IOException 
	 */
	@FXML
	public void saveSettingsButtonPressed() throws IOException {
		System.out.println("Entered to saveSettings as needed :) ");

		// first get the data that the user entered.
		String firstPlayerColorNum, secondPlayerColorNum, sizeOfBoard;
		int startPlayerInt, firstPlayerColorNumInt, secondPlayerColorNumInt, sizeOfBoardInt;

		try {
			if (this.players.getSelectedToggle().equals(playerOne)) {
				startPlayerInt = 1;
			} else {
				startPlayerInt = 2;
			}

			sizeOfBoard = boardSize.getText();
			// startPlayer = startingPlayerNum.getText();
			firstPlayerColorNum = firstPlayerColor.getText();
			secondPlayerColorNum = secondPlayerColor.getText();

			// convert them to integer.

			firstPlayerColorNumInt = Integer.parseInt(firstPlayerColorNum);
			secondPlayerColorNumInt = Integer.parseInt(secondPlayerColorNum);
			sizeOfBoardInt = Integer.parseInt(sizeOfBoard);
		} catch (NumberFormatException n) {
			System.out.println("Unvaild number,There is a problem to parse the data into  saveSettingsButtonPressed");
			return; // exit from the function.
		}

		// check if there are legal inputs
		if (startPlayerInt != 1 && startPlayerInt != 2) {
			// set the default (1)
			startPlayerInt = 1; // default value.
		}
		if (firstPlayerColorNumInt < 0 || firstPlayerColorNumInt > 5) {
			// set the default (1)
			firstPlayerColorNumInt = 1; // default value.
		}
		// the same for the second color of the player.
		if (secondPlayerColorNumInt < 0 || secondPlayerColorNumInt > 5) {
			// set the default (1)
			secondPlayerColorNumInt = 1; // default value.
		}

		// check the board's size.
		if (sizeOfBoardInt < 4 || sizeOfBoardInt > 20) {
			sizeOfBoardInt = 8; // default value.
		}

		// then call to helper function that writes the data to gameData file.
		writingNewDataToFile(startPlayerInt, firstPlayerColorNumInt, secondPlayerColorNumInt, sizeOfBoardInt);
		// then, return to the menu screen.
		AnchorPane root = (AnchorPane) FXMLLoader.load(getClass().getResource("Menu.fxml"));
		Stage currentStage = (Stage) saveSettingsButton.getScene().getWindow();
		currentStage.close(); // close the current scene.
		Scene settingsScene = new Scene(root, 600, 600); // define new scene
															// for the
															// settings
															// screen.
		currentStage.setTitle("Menu Screen");
		currentStage.setScene(settingsScene);
		//currentStage.settex("We got your new settings");
		currentStage.show();
		
	}

	private void writingNewDataToFile(int startPlayerInt, int firstPlayerColorNumInt, int secondPlayerColorNumInt,
			int sizeOfBoardInt) {
		String pathOfFile = "src/gameData.txt";
		try {
			BufferedWriter writerDescriptor = new BufferedWriter(new FileWriter(pathOfFile));
			/*
			 * First player is: 2. First player color is: Black. Second player
			 * color is: White. Size of the board: 9.
			 */
			PrintWriter writer = new PrintWriter(pathOfFile);
			writer.print("");
			writer.close();

			writerDescriptor.write("First player is: " + startPlayerInt + ".\n");
			writerDescriptor.write("First player color is: " + firstPlayerColorNumInt + ".\n");
			writerDescriptor.write("Second player color is: " + secondPlayerColorNumInt + ".\n");
			writerDescriptor.write("Size of the board: " + sizeOfBoardInt + ".");
			writerDescriptor.close();
		} catch (IOException e) {
			System.out.println("Can't write to the file, into writingNewDataToFile ");
		}

	}

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		players = new ToggleGroup();
		this.playerOne.setToggleGroup(players);
		this.playerTwo.setToggleGroup(players);

		GameData.getDataFromText(new File("src/gameData.txt"));
		this.start.setText(String.valueOf(GameData.playerThatStartInGame));
		this.start.setFill(Color.GREEN);
		this.one.setText(String.valueOf(GameData.firstPlayer));
		this.one.setFill(Color.RED);
		this.two.setText(String.valueOf(GameData.secondPlayer));
		this.two.setFill(Color.RED);
		this.size.setText(String.valueOf(GameData.RowNumber));
		this.size.setFill(Color.GREEN);


	}

}
