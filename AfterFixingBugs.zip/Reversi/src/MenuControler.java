
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class MenuControler implements Initializable {
	@FXML
	private RadioButton startButton;
	@FXML
	private RadioButton settingsButton;
	@FXML
	private Node enterButton;

	private ToggleGroup options;

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		// lab.setText("");
		options = new ToggleGroup();
		this.settingsButton.setToggleGroup(options);
		this.startButton.setToggleGroup(options);
	}

	@FXML
	public void enterWasPressed() throws IOException {
		// check which option the user chose as follows.
		if (this.options.getSelectedToggle().equals(startButton)) {
			// the player chose to start in the game
			System.out.println("Start was pressed");
			/**
			 * Need to call here the function that starts the game
			 */
		} else {
			// the player chose to see the settings screen.
			/**
			 * Show the settings screen.
			 */
			System.out.println("Settings was pressed");
			// open new scene with the settings screen as needed
			AnchorPane root = (AnchorPane) FXMLLoader.load(getClass().getResource("Settings.fxml"));
			Stage currentStage = (Stage) enterButton.getScene().getWindow();
			currentStage.close(); // close the current scene.
			Scene settingsScene = new Scene(root, 600, 600); // define new scene
																// for the
																// settings
																// screen.
			currentStage.setTitle("Settings Screen");
			currentStage.setScene(settingsScene);
			currentStage.show();
		}
	}
}
