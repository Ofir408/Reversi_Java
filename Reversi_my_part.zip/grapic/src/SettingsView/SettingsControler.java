package SettingsView;

import java.awt.TextField;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
public class SettingsControler implements Initializable {

	@FXML
	private TextField startingPlayerNum;
	@FXML
	private TextField firstPlayerColor;
	@FXML
	private TextField secondPlayerColor;
	@FXML
	private TextField boardSize;
	//@FXML
	//private Button saveSettingsButton; 

	/**
	 * This function is called when the save settings button is pressed. We want
	 * to save the new settings to gameData file.
	 */
	@FXML
	public void saveSettingsButtonPressed() {
		// first get the data that the user entered.
		String startPlayer, firstPlayerColorNum, secondPlayerColorNum, sizeOfBoard;
		int startPlayerInt, firstPlayerColorNumInt, secondPlayerColorNumInt, sizeOfBoardInt;
		startPlayer = startingPlayerNum.getText();
		firstPlayerColorNum = firstPlayerColor.getText();
		secondPlayerColorNum = secondPlayerColor.getText();
		sizeOfBoard = boardSize.getText();

		// convert them to integer.
		try {
			startPlayerInt = Integer.parseInt(startPlayer);
			firstPlayerColorNumInt = Integer.parseInt(firstPlayerColorNum);
			secondPlayerColorNumInt = Integer.parseInt(secondPlayerColorNum);
			sizeOfBoardInt = Integer.parseInt(sizeOfBoard);
		} catch (NumberFormatException n) {
			System.out.println("Unvaild number,There is a problem to parse the data into  saveSettingsButtonPressed");
			return; // exit from the function.
		}

		// check if there are legal inputs
		if (startPlayerInt != 1 && startPlayerInt != 2) {
			// set the default (1)
			startPlayerInt = 1; // default value.
		}
		if (firstPlayerColorNumInt < 0 || firstPlayerColorNumInt > 5) {
			// set the default (1)
			firstPlayerColorNumInt = 1; // default value.
		}
		// the same for the second color of the player.
		if (secondPlayerColorNumInt < 0 || secondPlayerColorNumInt > 5) {
			// set the default (1)
			secondPlayerColorNumInt = 1; // default value.
		}

		// check the board's size.
		if (sizeOfBoardInt < 4 || sizeOfBoardInt > 20) {
			sizeOfBoardInt = 8; // default value.
		}

		// then call to helper function that writes the data to gameData file.
		writingNewDataToFile(startPlayerInt, firstPlayerColorNumInt, secondPlayerColorNumInt, sizeOfBoardInt);
	}

	private void writingNewDataToFile(int startPlayerInt, int firstPlayerColorNumInt, int secondPlayerColorNumInt, int sizeOfBoardInt) {
		String pathOfFile = "src/gameData.txt";
        try {
			BufferedWriter writerDescriptor = new BufferedWriter(new FileWriter(pathOfFile));
			/*First player is: 2.
			First player color is: Black.
			Second player color is: White.
			Size of the board: 9.*/
			writerDescriptor.write("First player is: " + startPlayerInt + ".");
			writerDescriptor.write("First player color is: " + firstPlayerColorNumInt  + ".");
			writerDescriptor.write("Second player color is: " + secondPlayerColorNumInt + ".");
			writerDescriptor.write("Size of the board: " + sizeOfBoardInt + ".");
			writerDescriptor.close();
		} catch (IOException e) {
			System.out.println("Can't write to the file, into writingNewDataToFile ");
		}

	}

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		// TODO Auto-generated method stub
		
	}

}
