package SettingsView;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;

public class MenuControler implements Initializable {
	@FXML
	private RadioButton startButton; 
	@FXML
	private RadioButton settingsButton;
	@FXML
	private Label lab; 
	
	private ToggleGroup options; 
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		lab.setText("");
		options = new ToggleGroup(); 
		this.settingsButton.setToggleGroup(options);
		this.startButton.setToggleGroup(options);
	} 
	
	@FXML
	public void trying() {
		System.out.println("Hello world");
	}
	
	@FXML
	public void enterWasPressed() {
		// check which option the user chose as follows.
		if (this.options.getSelectedToggle().equals("Start")) {
			// the player chose to start in the game
			
			/**
			 * Need to call here the function that starts the game
			 */
		} else {
			// the player chose to see the settings screen.
			/**
			 * Show the settings screen.
			 */
		}
		
		
	}
	
	}
	
	
