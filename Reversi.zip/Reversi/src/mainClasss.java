import java.io.File;

public class mainClasss {

	public static void main(String[] args) {
		/*
		 * main.cpp
		 *
		 * Created on: Oct 25, 2017 Author: Ofir Ben-Shoham And Yuval. ID:
		 * 208642496.
		 */
		File file = new File("src/gameData.txt");
		GameData.getDataFromText(file);

		Board b = new Board();

		b.printBoard();

		try {
			GameRunner gr = new GameRunner(b, 'X');
			gr.run();
		} catch (Exception e) {
			System.out.println("exception was catched :( ");
		}
	}
}

