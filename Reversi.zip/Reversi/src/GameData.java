import java.io.*;

public class GameData {
	public static int RowNumber = 8;
	public static int ColNumber = 8;
	public static String firstPlayer, secondPlayer;
	public static int playerThatStartInGame;

	static void getDataFromText(File fileDes) {
		BufferedReader reader = null;
		int firstPlayerIndex, firstPlayerColorIndex, secondPlayerColorIndex, sizeBoardIndex, endOfCurrentData;
		try {
			reader = new BufferedReader(new FileReader(fileDes));
			String currentLine;
			while ((currentLine = reader.readLine()) != null) {
				// here for each line
				if ((firstPlayerIndex = currentLine.indexOf("First player is:")) >= 0) {
					if ((endOfCurrentData = currentLine.indexOf(".")) > 0) {
						String tempStartData = currentLine.substring(firstPlayerIndex + "First player is:".length() + 1, endOfCurrentData);
						// it should be as an integer string - who starts in the
						// game.
						GameData.playerThatStartInGame = Integer.parseInt(tempStartData);
					}
				}

				// read the first player color.
				if ((firstPlayerColorIndex = currentLine.indexOf("First player color is:")) >= 0) {
					if ((endOfCurrentData = currentLine.indexOf(".")) > 0) {
						GameData.firstPlayer = currentLine.substring(firstPlayerColorIndex + "First player color is:".length() +1, endOfCurrentData);
					}
				}

				// read the second player color
				if ((secondPlayerColorIndex = currentLine.indexOf("Second player color is:")) >= 0) {
					if ((endOfCurrentData = currentLine.indexOf(".")) > 0) {
						GameData.secondPlayer = currentLine.substring(secondPlayerColorIndex + "First player color is:".length() + 1, endOfCurrentData);
					}
				}

				// read the size of the board
				if ((sizeBoardIndex = currentLine.indexOf("Size of the board:")) >= 0) {
					if ((endOfCurrentData = currentLine.indexOf(".")) > 0) {
						String temp = currentLine.substring(sizeBoardIndex + 1 + "Size of the board:".length(), endOfCurrentData);
						GameData.RowNumber = Integer.parseInt(temp);
						GameData.ColNumber = GameData.RowNumber;
					}
				}
			}
		} catch (FileNotFoundException e) {
			System.out.println("Problem into GameData::getDataFromText ");
		} catch (IOException io) {
			System.out.println("IOException into GameData::getDataFromText ");
		}
	}
}
